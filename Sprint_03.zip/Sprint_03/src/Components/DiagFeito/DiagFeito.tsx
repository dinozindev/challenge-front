const DiagFeito =() => {
    return(
        <>
            <h1>Diagnostico Realizado!</h1>
        </>
    )
}
export default DiagFeito;