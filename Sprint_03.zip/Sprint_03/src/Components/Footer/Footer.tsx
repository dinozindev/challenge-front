const Footer = () => {
    return(
        <>
         <div className="Content-responsive_01">
            <h1>este e o footer</h1>
        </div>
        </>
    )
}

export default Footer;